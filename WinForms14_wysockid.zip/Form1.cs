﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PWSG_LAB5
{
    public partial class Form1 : Form
    {
        const int xSize = 10;
        const int ySize = 10;
        Button[,] tiles = new Button[xSize,ySize];
        Random rng;

        Label[] rowLabels = new Label[ySize];
        Label[] colLabels = new Label[xSize];

        public Form1()
        {
            rng = new Random();
            InitializeComponent();
            this.Shown += CreateTiles;
            this.Shown += CreateLabels;
        }

        // https://stackoverflow.com/questions/47732560/how-can-i-create-a-button-programmatically-in-c-sharp-window-app
        private void CreateTiles(object sender, EventArgs e)
        {
            for (int i = 0; i < xSize; i++)
            {
                for (int j = 0; j < ySize; j++)
                {
                    Button tile = new Button();
                    tile.BackColor = rng.Next(0,2) == 0 ? System.Drawing.Color.White : System.Drawing.Color.Black;
                    tile.Dock = System.Windows.Forms.DockStyle.Fill;
                    tile.FlatAppearance.BorderColor = System.Drawing.Color.Black;
                    tile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
                    tile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
                    tile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                    tile.Location = new System.Drawing.Point(30 * i, 30 * j);
                    tile.Margin = new System.Windows.Forms.Padding(0);
                    tile.Name = $"tile: {i},{j}";
                    tile.Size = new System.Drawing.Size(30, 30);
                    tile.TabIndex = 1;
                    tile.UseVisualStyleBackColor = false;
                    tile.Click += new System.EventHandler(this.tile_Click);
                    tiles[i, j] = tile;
                    // https://stackoverflow.com/questions/42840406/adding-dynamic-controls-to-tablelayoutpanel-in-net-windows-form
                    this.tableLayoutPanel1.Controls.Add(tile);
                }
            }
        }

        private void CreateLabels(object sender, EventArgs e)
        {
            int startX = tableLayoutPanel1.Location.X;
            int startY = tableLayoutPanel1.Location.Y;

            // col
            for (int i = 0; i < xSize; i++)
            {
                const int height = 40;
                Label label = new Label();
                this.Controls.Add(label);
                label.Text = EvaluateCol(i);
                // dobrze sie alignuje dla zwyklego tekstu evalutecol i row cos psuja
                // zabraklo czasu zeby znalezc co dokladnie
                label.TextAlign = ContentAlignment.BottomCenter; 
                label.AutoSize = false;
                label.Size = new Size(30, height);
                label.Margin = new Padding(0);
                label.Location = new Point(startX + 30 * i, startY - height);
                colLabels[i] = label;
            }

            // row
            for (int i = 0; i < ySize; i++)
            {
                const int width = 40;
                Label label = new Label();
                this.Controls.Add(label);
                label.Text = EvaluateRow(i);
                label.TextAlign = ContentAlignment.MiddleRight;
                label.AutoSize = false;
                label.Size = new Size(width, 30);
                label.Margin = new Padding(0);
                label.Location = new Point(startX - width, startY + 30 * i);
                rowLabels[i] = label;
            }
        }

        private string EvaluateRow(int rowNo)
        {
            StringBuilder sb = new StringBuilder();

            int curLen = 0;
            for(int i = 0; i < xSize; i++)
            {
                Color color = tiles[rowNo, i].BackColor;
                if(color == Color.Black)
                {
                    curLen++;
                }
                else if (curLen != 0)
                {
                    if (sb.Length > 0) sb.Append(' ');
                    sb.Append(curLen.ToString());
                    curLen = 0;
                }
            }
            if (curLen > 0)
                sb.Append(curLen.ToString());

            if (sb.Length == 0)
                return "0";

            return sb.ToString();
        }

        private string EvaluateCol(int colNo)
        {
            StringBuilder sb = new StringBuilder();

            int curLen = 0;
            for (int i = 0; i < ySize; i++)
            {
                Color color = tiles[i, colNo].BackColor;
                if (color == Color.Black)
                {
                    curLen++;
                }
                else if (curLen != 0)
                {
                    sb.AppendLine(curLen.ToString());
                    curLen = 0;
                }
            }
            if (curLen > 0)
                sb.AppendLine(curLen.ToString());

            if (sb.Length == 0)
                return "0";

            return sb.ToString();
        }

        private void tile_Click(object sender, EventArgs e)
        {
            Button tile = (Button)sender;
            tile.BackColor = tile.BackColor == System.Drawing.Color.White ? System.Drawing.Color.Black : System.Drawing.Color.White;
        }
    }

    //public class TileButton : Button
    //{
    //    public TileButton()
    //    {
    //tile.BackColor = System.Drawing.Color.White;
    //        this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
    //        this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
    //        this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
    //        this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
    //        this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
    //        this.button1.Location = new System.Drawing.Point(0, 0);
    //        this.button1.Margin = new System.Windows.Forms.Padding(0);
    //        this.button1.Name = "button1";
    //        this.button1.Size = new System.Drawing.Size(30, 30);
    //        this.button1.TabIndex = 1;
    //        this.button1.UseVisualStyleBackColor = false;
    //        Button();
    //    }
    //}
}
